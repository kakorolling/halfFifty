public enum TerrainType
{
    None,
    Ground,
    Grassland,
    Sand,
    FreshWater,
    SeaWater,
    Farmland
}