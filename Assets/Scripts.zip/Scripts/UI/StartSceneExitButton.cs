using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartSceneExitButton : MonoBehaviour
{
    // Start is called before the first frame update
    public void GameQuit()
    {
        Application.Quit();
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
